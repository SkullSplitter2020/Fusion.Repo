PlexKodiConnect Repository
==========================

* Github:	<https://github.com/croneter/repository.plexkodiconnect>

Usage
-----
Simply download the repository zip and install it, or use XBMC's repository installer plugin.

Questions, Comments, Concerns, Issues
-------------------------------------
If you have any of these, go ahead and [submit an issue](https://github.com/croneter/repository.plexkodiconnect/issues),

List of addons available
------------------------
* PlexKodiConnect (main plugin, stable and develop branch)
* plugin.video.plexkodiconnect.movies (dependency plugin)
* plugin.video.plexkodiconnect.tvshows (dependency plugin)