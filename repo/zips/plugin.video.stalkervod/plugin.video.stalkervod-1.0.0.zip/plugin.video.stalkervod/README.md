# Stalker VOD Kodi add-on
**plugin.video.stalkervod** is a [Kodi](https://kodi.tv/) add-on for Stalker platform IPTV Client. You can watch Video On-Demand as well as TV Channels.

v1.0.0  (2024-07-13)
- Major version release with refactor of the menu options. Support for portal with separate menu option for Series.
If using kodi Add to Favourites option, existing Favourites link would break.
Ability to use Portal Favorite option for both VOD and TV Channels
Add support for UpNext addon.