# -*- coding: utf-8 -*-
"""Context menu entry point"""

from __future__ import absolute_import, division, unicode_literals

from resources.lib.functions import run

run([-1, 'play_from_contextmenu'])
