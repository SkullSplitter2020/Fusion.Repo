# Animated Artwork Extension #

With this module a skinner is able to add a menu entry in Kodi context menu for showing, adding and deleting animated posters. Activating this module is done by setting the skin setting (boolean) `Skin_EnableAnimatedPosters` which has labeled e.g. "Show, add and remove animated posters". Also a path in the local file system is needed that contains all animated artwork and is set by skin string `Skin.String(ap_source)`. This path can also contain nested subdirectories. 


![](resources/media/screenshot_01.png)